Project Title: Simple Restaurant Menu Page
Author: Swan Htet Aung

Description:
- This is a simple responsive menu webpage made with HTML and CSS.
- I used semantic HTML elements such as section, article, header, footer.
- I added mobile responsiveness using media queries.

Skills Learned:
- Flexbox layout
- Responsive design
- Semantic HTML structure
- CSS styling and button design